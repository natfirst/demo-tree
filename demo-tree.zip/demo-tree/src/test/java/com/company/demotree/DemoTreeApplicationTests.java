package com.company.demotree;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoTreeApplicationTests {

	@Test
	void contextLoads() {
	}

}
